# padm_env.py
import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
import os

class ThanosEscapeEnv(gym.Env):
    def __init__(self, grid_size=7):
        super(ThanosEscapeEnv, self).__init__()
        self.grid_size = grid_size
        self.agent_state = np.array([1, 1])  # Initial position of Thanos
        self.gauntlet_state = np.array([self.grid_size - 2, self.grid_size - 2])  # Position of the Infinity Gauntlet
        self.avengers_states = [[3, 2], [5, 4], [2, 5]]  # Positions of the Avengers (Hell-States)
        self.action_space = gym.spaces.Discrete(4)  # Actions: Up, Down, Left, Right
        self.observation_space = gym.spaces.Box(low=0, high=self.grid_size, shape=(2,))  # Grid coordinates
        self.fig, self.ax = plt.subplots()
        plt.show(block=False)

        # Load icon images from local icons folder
        self.thanos_icon = self.load_icon('icons/thanos.png')
        self.gauntlet_icon = self.load_icon('icons/gauntlet.png')
        self.avenger_icons = [
            self.load_icon('icons/avenger1.png'),
            self.load_icon('icons/avenger2.png'),
            self.load_icon('icons/avenger3.png')
        ]

    def load_icon(self, path):
        """Load an icon image from a specified path."""
        if os.path.exists(path):
            return plt.imread(path)
        else:
            print(f"Failed to load icon from {path}")
            return None

    def reset(self):
        """Reset the environment to its initial state."""
        self.agent_state = np.array([1, 1])  # Reset Thanos to initial position
        return self.agent_state

    def step(self, action):
        """Take an action and update the environment state."""
        if action == 0 and self.agent_state[1] < self.grid_size - 1:  # Up
            self.agent_state[1] += 1
        elif action == 1 and self.agent_state[1] > 0:  # Down
            self.agent_state[1] -= 1
        elif action == 2 and self.agent_state[0] > 0:  # Left
            self.agent_state[0] -= 1
        elif action == 3 and self.agent_state[0] < self.grid_size - 1:  # Right
            self.agent_state[0] += 1

        reward = 0
        done = False

        if np.array_equal(self.agent_state, self.gauntlet_state):
            reward = 100.0
            done = True

        if list(self.agent_state) in self.avengers_states:
            reward = -50.0
            done = True

        distance_to_gauntlet = np.linalg.norm(self.gauntlet_state - self.agent_state)
        info = {"distance_to_gauntlet": distance_to_gauntlet}

        return self.agent_state, reward, done, info

    def render(self):
        """Render the current state of the environment."""
        self.ax.clear()
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                self.ax.plot(x, y, 's', color='lightgray', markersize=30, zorder=0)

        self.ax.imshow(self.thanos_icon, extent=[self.agent_state[0]-0.5, self.agent_state[0]+0.5, self.agent_state[1]-0.5, self.agent_state[1]+0.5], zorder=1)
        self.ax.imshow(self.gauntlet_icon, extent=[self.gauntlet_state[0]-0.5, self.gauntlet_state[0]+0.5, self.gauntlet_state[1]-0.5, self.gauntlet_state[1]+0.5], zorder=1)
        for i, avenger_state in enumerate(self.avengers_states):
            self.ax.imshow(self.avenger_icons[i], extent=[avenger_state[0]-0.5, avenger_state[0]+0.5, avenger_state[1]-0.5, avenger_state[1]+0.5], zorder=1)

        self.ax.set_xlim(-1, self.grid_size)
        self.ax.set_ylim(-1, self.grid_size)
        self.ax.set_aspect("equal")
        plt.pause(0.1)

    def close(self):
        """Close the rendering window."""
        plt.close()
