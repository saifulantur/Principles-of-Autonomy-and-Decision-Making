import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
import os

class ThanosEscapeEnv(gym.Env):
    """
    Custom environment for Thanos to escape and collect the Infinity Gauntlet
    while avoiding the Avengers.
    """
    def __init__(self, grid_size=7):
        super().__init__()
        self.grid_size = grid_size  # Define the size of the grid
        self.agent_state = np.array([1, 1])  # Initial position of Thanos
        self.gauntlet_state = np.array([self.grid_size - 2, self.grid_size - 2])  # Position of the Infinity Gauntlet
        self.avengers_states = [[3, 2], [5, 4], [2, 5]]  # Positions of the Avengers (Hell-States)

        # Define the action space (4 possible actions: Up, Down, Left, Right)
        self.action_space = gym.spaces.Discrete(4)

        # Define the observation space (coordinates on the grid)
        self.observation_space = gym.spaces.Box(low=0, high=self.grid_size, shape=(2,))

        # Initialize the plot for rendering
        self.fig, self.ax = plt.subplots()
        plt.show(block=False)  # Allow interactive mode for the plot

        # Load icon images from local icons folder
        self.thanos_icon = self.load_icon('icons/thanos.png')
        self.gauntlet_icon = self.load_icon('icons/gauntlet.png')
        self.avenger_icons = [
            self.load_icon('icons/avenger1.png'),
            self.load_icon('icons/avenger2.png'),
            self.load_icon('icons/avenger3.png')
        ]

    def load_icon(self, path):
        """
        Load an icon image from a specified path.
        """
        if os.path.exists(path):
            try:
                return plt.imread(path)  # Load the image file
            except Exception as e:
                print(f"Error loading image from {path}: {e}")
                return None
        else:
            print(f"Failed to load icon from {path} (file does not exist)")
            return None

    def reset(self):
        """
        Reset the environment to its initial state.
        """
        self.agent_state = np.array([1, 1])  # Reset Thanos to initial position
        return self.agent_state

    def step(self, action):
        """
        Take an action and update the environment state.

        Parameters:
        action (int): The action to be taken (0: Up, 1: Down, 2: Left, 3: Right)

        Returns:
        tuple: A tuple containing the new state, reward, done flag, and additional info.
        """
        # Move Thanos based on the action
        if action == 0 and self.agent_state[1] < self.grid_size - 1:  # Up
            self.agent_state[1] += 1
        elif action == 1 and self.agent_state[1] > 0:  # Down
            self.agent_state[1] -= 1
        elif action == 2 and self.agent_state[0] > 0:  # Left
            self.agent_state[0] -= 1
        elif action == 3 and self.agent_state[0] < self.grid_size - 1:  # Right
            self.agent_state[0] += 1

        reward = 0  # Initialize the reward
        done = False  # Initialize the done flag

        # Check if Thanos collected the Infinity Gauntlet
        if np.array_equal(self.agent_state, self.gauntlet_state):
            reward = 100.0  # Reward for collecting the Gauntlet
            done = True  # End the episode

        # Check if Thanos encountered an Avenger (Hell-State)
        if list(self.agent_state) in self.avengers_states:
            reward = -50.0  # Penalty for encountering an Avenger
            done = True  # End the episode

        # Calculate the Euclidean distance to the Gauntlet
        distance_to_gauntlet = np.linalg.norm(self.gauntlet_state - self.agent_state)
        info = {"distance_to_gauntlet": distance_to_gauntlet}

        return self.agent_state, reward, done, info

    def render(self):
        """
        Render the current state of the environment.
        """
        self.ax.clear()  # Clear previous plot

        # Plot the grid
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                self.ax.plot(x, y, 's', color='lightgray', markersize=30, zorder=0)

        # Plot Thanos
        if self.thanos_icon is not None:
            self.ax.imshow(self.thanos_icon, extent=[self.agent_state[0]-0.5, self.agent_state[0]+0.5, self.agent_state[1]-0.5, self.agent_state[1]+0.5], zorder=1)
        else:
            print("Thanos icon is not loaded")

        # Plot the Infinity Gauntlet
        if self.gauntlet_icon is not None:
            self.ax.imshow(self.gauntlet_icon, extent=[self.gauntlet_state[0]-0.5, self.gauntlet_state[0]+0.5, self.gauntlet_state[1]-0.5, self.gauntlet_state[1]+0.5], zorder=1)
        else:
            print("Gauntlet icon is not loaded")

        # Plot the Avengers (Hell-States)
        for i, avenger_state in enumerate(self.avengers_states):
            if self.avenger_icons[i] is not None:
                self.ax.imshow(self.avenger_icons[i], extent=[avenger_state[0]-0.5, avenger_state[0]+0.5, avenger_state[1]-0.5, avenger_state[1]+0.5], zorder=1)
            else:
                print(f"Avenger {i+1} icon is not loaded")

        # Set plot limits and aspect ratio
        self.ax.set_xlim(-1, self.grid_size)
        self.ax.set_ylim(-1, self.grid_size)
        self.ax.set_aspect("equal")

        # Pause to update the plot
        plt.pause(0.1)

    def close(self):
        """
        Close the rendering window.
        """
        plt.close()

if __name__ == "__main__":
    # Print the current working directory for debugging purposes
    print("Current working directory:", os.getcwd())

    env = ThanosEscapeEnv()
    state = env.reset()
    total_reward = 0

    # Run the environment for a maximum of 500 steps
    for _ in range(500):
        action = env.action_space.sample()  # Random action for demonstration
        state, reward, done, info = env.step(action=action)
        total_reward += reward  # Accumulate the reward
        env.render()  # Render the environment
        print(f"State: {state}, Reward: {reward}, Total Reward: {total_reward}, Done: {done}, Info: {info}")
        if done:  # Check if the episode has ended
            if reward > 0:
                print("Congratulations! Thanos collected the Infinity Gauntlet!")
            else:
                print("Oh no! Thanos encountered an Avenger!")
            break

    env.close()  # Close the environment
