import numpy as np

# Define the grid world parameters
gamma = 0.9  # Discount factor
reward_goal = 10
reward_danger = -1
reward_living = -0.1

# Define the grid world
grid_size = 4
V = np.zeros((grid_size, grid_size))  # Initialize value function to zero
V[2, 1] = reward_danger
V[2, 3] = reward_danger
V[3, 3] = reward_goal

# Define possible actions
actions = ['up', 'down', 'left', 'right']
action_vectors = {'up': (-1, 0), 'down': (1, 0), 'left': (0, -1), 'right': (0, 1)}

# Transition probabilities
p_intended = 0.7
p_others = 0.1

def is_valid_state(x, y):
    return 0 <= x < grid_size and 0 <= y < grid_size

def step(x, y, action):
    dx, dy = action_vectors[action]
    next_x, next_y = x + dx, y + dy
    if is_valid_state(next_x, next_y):
        return next_x, next_y
    return x, y

def value_iteration(V, gamma, iterations):
    for _ in range(iterations):
        V_new = np.copy(V)
        for i in range(grid_size):
            for j in range(grid_size):
                if (i, j) == (3, 3) or (i, j) == (2, 1) or (i, j) == (2, 3):  # Skip the goal and danger states
                    continue
                action_values = []
                for action in actions:
                    value = 0
                    for act in actions:
                        next_i, next_j = step(i, j, act)
                        prob = p_intended if act == action else p_others
                        value += prob * (reward_living + gamma * V[next_i, next_j])
                    action_values.append(value)
                V_new[i, j] = max(action_values)
        V = V_new
    return V

def calculate_q_values(V, gamma):
    Q = np.zeros((grid_size, grid_size, len(actions)))
    for i in range(grid_size):
        for j in range(grid_size):
            if (i, j) == (3, 3) or (i, j) == (2, 1) or (i, j) == (2, 3):  # Skip the goal and danger states
                continue
            for idx, action in enumerate(actions):
                for act in actions:
                    next_i, next_j = step(i, j, act)
                    prob = p_intended if act == action else p_others
                    Q[i, j, idx] += prob * (reward_living + gamma * V[next_i, next_j])
    return Q

def main():
    while True:
        user_input = input("Enter the iteration number for V_n(s) or 'Q5' for Q5(s,a) or 'exit' to quit: ").strip().lower()
        
        if user_input == 'exit':
            break
        elif user_input.startswith('v'):
            try:
                n = int(user_input[1:])
                V_n = value_iteration(V, gamma, n)
                print(f"\nV_{n}(s) after {n} iterations:")
                print(V_n)
            except ValueError:
                print("Invalid input. Please enter a valid iteration number for V_n(s).")
        elif user_input == 'q5':
            V_5 = value_iteration(V, gamma, 5)
            Q_5 = calculate_q_values(V_5, gamma)
            print("\nQ_5(s, a) after 5 iterations:")
            for i in range(grid_size):
                for j in range(grid_size):
                    for idx, action in enumerate(actions):
                        print(f"Q_5({i+1},{j+1},{action}) = {Q_5[i, j, idx]:.2f}")
        else:
            print("Invalid input. Please enter 'Vn' (e.g., 'V1', 'V3') or 'Q5' or 'exit'.")

if __name__ == "__main__":
    main()
