import torch
import matplotlib.pyplot as plt
from padm_env import EscapeEnv
from DQN_model import DQN
from utils import train_dqn, test_dqn

# Hyperparameters
BATCH_SIZE = 128
GAMMA = 0.99
EPS_START = 1.0
EPS_END = 0.01
EPS_DECAY = 0.999
TARGET_UPDATE = 10
NUM_EPISODES = 5000 
LEARNING_RATE = 0.0005

def main():
    env = EscapeEnv()
    n_actions = env.action_space.n
    n_observations = env.observation_space.shape[0]

    policy_net = DQN(n_observations, n_actions)
    target_net = DQN(n_observations, n_actions)
    target_net.load_state_dict(policy_net.state_dict())

    optimizer = torch.optim.Adam(policy_net.parameters(), lr=LEARNING_RATE)

    # Train the DQN agent
    episode_rewards, _ = train_dqn(env, policy_net, target_net, optimizer, NUM_EPISODES, BATCH_SIZE, GAMMA, EPS_START, EPS_END, EPS_DECAY, TARGET_UPDATE)

    # Save the model weights
    torch.save(policy_net.state_dict(), "dqn.pth")

    # Generate and save the training curve
    plt.figure(figsize=(10, 6))
    plt.plot(episode_rewards, color='blue', label='Reward per Episode')
    plt.title("Training Rewards")
    plt.xlabel("Episode")
    plt.ylabel("Rewards")
    plt.legend()
    plt.tight_layout()
    plt.savefig("training_curve.png")
    plt.show()

    # Test the trained agent
    test_dqn(env, policy_net)

if __name__ == "__main__":
    main()