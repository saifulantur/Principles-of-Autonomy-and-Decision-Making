import gymnasium as gym
import numpy as np

class EscapeEnv(gym.Env):
    def __init__(self, grid_size=7):
        super(EscapeEnv, self).__init__()
        self.grid_size = grid_size
        self.agent_state = np.array([1, 1])  # Initial position of the agent
        self.goal_state = np.array([self.grid_size - 2, self.grid_size - 2])  # Position of the goal
        self.hell_states = [[3, 2], [5, 4], [2, 5]]  # Positions of the hell states
        self.action_space = gym.spaces.Discrete(4)  # Actions: Up, Down, Left, Right
        self.observation_space = gym.spaces.Box(low=0, high=self.grid_size - 1, shape=(2,), dtype=np.float32)  # Grid coordinates
        self.max_steps = self.grid_size * self.grid_size * 2  # Maximum steps per episode
        self.current_step = 0

    def reset(self):
        self.agent_state = np.array([1, 1])  # Reset agent to initial position
        self.current_step = 0
        return self.agent_state.astype(np.float32)

    def step(self, action):
        self.current_step += 1
        
        if action == 0 and self.agent_state[1] < self.grid_size - 1:  # Up
            self.agent_state[1] += 1
        elif action == 1 and self.agent_state[1] > 0:  # Down
            self.agent_state[1] -= 1
        elif action == 2 and self.agent_state[0] > 0:  # Left
            self.agent_state[0] -= 1
        elif action == 3 and self.agent_state[0] < self.grid_size - 1:  # Right
            self.agent_state[0] += 1

        reward = -0.1  # Small negative reward for each step
        done = False

        if np.array_equal(self.agent_state, self.goal_state):
            reward = 10.0
            done = True
        elif list(self.agent_state) in self.hell_states:
            reward = -10.0
            done = True
        elif self.current_step >= self.max_steps:
            done = True

        info = {}
        return self.agent_state.astype(np.float32), reward, done, info

    def render(self):
        grid = np.zeros((self.grid_size, self.grid_size), dtype=str)
        grid.fill('.')
        grid[tuple(self.agent_state)] = 'A'
        grid[tuple(self.goal_state)] = 'G'
        for hell in self.hell_states:
            grid[tuple(hell)] = 'H'
        print(grid)

    def close(self):
        pass