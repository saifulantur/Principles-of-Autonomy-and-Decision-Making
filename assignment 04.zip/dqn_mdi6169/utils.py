import torch
import torch.nn as nn
import random
import numpy as np
from collections import deque

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        state, action, reward, next_state, done = zip(*random.sample(self.buffer, batch_size))
        return (torch.FloatTensor(state).to(device),
                torch.LongTensor(action).to(device),
                torch.FloatTensor(reward).to(device),
                torch.FloatTensor(next_state).to(device),
                torch.FloatTensor(done).to(device))

    def __len__(self):
        return len(self.buffer)

def train_dqn(env, policy_net, target_net, optimizer, num_episodes, batch_size, gamma, eps_start, eps_end, eps_decay, target_update):
    replay_buffer = ReplayBuffer(10000)
    epsilon = eps_start
    episode_rewards = []
    epsilon_values = []

    for episode in range(num_episodes):
        state = env.reset()
        total_reward = 0
        done = False

        while not done:
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                with torch.no_grad():
                    action = policy_net(torch.FloatTensor(state).unsqueeze(0).to(device)).max(1)[1].view(1, 1).item()

            next_state, reward, done, _ = env.step(action)
            replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            total_reward += reward

            if len(replay_buffer) > batch_size:
                batch = replay_buffer.sample(batch_size)
                state_batch, action_batch, reward_batch, next_state_batch, done_batch = batch

                q_values = policy_net(state_batch).gather(1, action_batch.unsqueeze(1))
                next_q_values = target_net(next_state_batch).max(1)[0].detach()
                expected_q_values = reward_batch + gamma * next_q_values * (1 - done_batch)

                loss = nn.MSELoss()(q_values, expected_q_values.unsqueeze(1))
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        if episode % target_update == 0:
            target_net.load_state_dict(policy_net.state_dict())

        epsilon = max(eps_end, epsilon * eps_decay)
        episode_rewards.append(total_reward)
        epsilon_values.append(epsilon)

        print(f"Episode {episode + 1}/{num_episodes}, Total Reward: {total_reward:.2f}, Epsilon: {epsilon:.2f}")

        # Early stopping condition
        if episode > 100 and np.mean(episode_rewards[-100:]) > 5:
            print("Early stopping: Agent has learned to consistently reach the goal")
            break

    return episode_rewards, epsilon_values

def test_dqn(env, policy_net, num_episodes=10):
    for episode in range(num_episodes):
        state = env.reset()
        total_reward = 0
        done = False

        while not done:
            env.render()
            with torch.no_grad():
                action = policy_net(torch.FloatTensor(state).unsqueeze(0).to(device)).max(1)[1].view(1, 1).item()
            next_state, reward, done, _ = env.step(action)
            state = next_state
            total_reward += reward

        print(f"Test Episode {episode + 1}/{num_episodes}, Total Reward: {total_reward:.2f}")
    env.close()